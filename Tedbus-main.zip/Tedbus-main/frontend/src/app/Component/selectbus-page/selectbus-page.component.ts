import { Component } from '@angular/core';

@Component({
  selector: 'app-selectbus-page',
  templateUrl: './selectbus-page.component.html',
  styleUrl: './selectbus-page.component.css'
})
export class SelectbusPageComponent {

}
