export interface Customer{
    id?:string;
    name:string;
    googleId?:string;
    age?:number;
    gender?:string;
    email:string;
    dateofbirth?:string;
    profilepicture?:string;
}